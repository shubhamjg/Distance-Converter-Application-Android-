package com.example.distanceconverter;

import android.nfc.Tag;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {


    //Assignment 1 Shubham Jitendra Gandhi K00442066
RadioGroup rg1;
RadioGroup rg2;
Button button;
EditText editText;
TextView textView;
double inunit,outunit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText=(EditText)findViewById(R.id.editText);
        textView=(TextView)findViewById(R.id.textView);
        button=(Button)findViewById(R.id.button);
        rg1=(RadioGroup)findViewById(R.id.rg1);
        rg2=(RadioGroup)findViewById(R.id.rg2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int sid=rg1.getCheckedRadioButtonId();
                int sout=rg2.getCheckedRadioButtonId();

                if(TextUtils.isEmpty(editText.getText().toString()))
                {
                    return;
                }
                inunit=Double.parseDouble(editText.getText().toString());

                switch (sid){

                    case R.id.radioButton:
                        inunit=inunit*1;
                        break;
                    case R.id.radioButton2:
                        inunit=inunit*12;
                        break;
                    case R.id.radioButton3:
                        inunit=inunit*36;
                        break;
                    case R.id.radioButton4:
                        inunit=inunit*63360;
                        break;
                    case R.id.radioButton5:
                        inunit=inunit/2.54;
                        break;
                    case R.id.radioButton6:
                        inunit=inunit*39.37;
                        break;
                    case R.id.radioButton7:
                        inunit=inunit*39370.079;
                        break;
                        default:
                            break;


                }
                switch (sout){
                    case R.id.radioButton8:
                        outunit=inunit*1;
                        break;
                    case R.id.radioButton9:
                        outunit=inunit/12;
                        break;
                    case R.id.radioButton10:
                        outunit=inunit/36;
                        break;
                    case R.id.radioButton11:
                        outunit=inunit/63360;
                        break;
                    case R.id.radioButton12:
                        outunit=inunit*2.54;
                        break;
                    case R.id.radioButton13:
                        outunit=(inunit/(39.37));
                        break;
                    case R.id.radioButton14:
                        outunit=(inunit/(39370.079));
                        break;
                        default:
                            break;
                }
                DecimalFormat format= new DecimalFormat("#,##0.0000000");
                textView.setText(format.format(outunit));
            }
        });

    }
}
